import os
import glob
from typing import List, Optional
from fastapi import FastAPI, Body
from pydantic import BaseModel

from langchain_community.vectorstores import FAISS
from langchain_community.docstore.document import Document
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_openai import ChatOpenAI
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema.runnable import RunnablePassthrough
from langchain.prompts import ChatPromptTemplate

TENANT_ID = os.getenv("TENANT_ID", "tenant_unknown")
DATA_DIR = "/app/data"
INDEX_DIR = "/app/indices"
VLLM_BASE_URL = os.getenv("VLLM_BASE_URL")  # e.g., http://vllm:8000/v1
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "dummy")

# ---- Embeddings (CPU by default) ----
EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
embeddings = HuggingFaceEmbeddings(model_name=EMBED_MODEL)

# ---- Load or build per-tenant FAISS index ----
def load_or_build_index():
    os.makedirs(INDEX_DIR, exist_ok=True)
    faiss_path = os.path.join(INDEX_DIR, "faiss_index")
    if os.path.exists(faiss_path):
        return FAISS.load_local(faiss_path, embeddings, allow_dangerous_deserialization=True)

    # Ingest .txt files under /app/data (each file becomes a doc)
    files = sorted(glob.glob(os.path.join(DATA_DIR, "**/*.txt"), recursive=True))
    docs: List[Document] = []
    for fp in files:
        with open(fp, "r", encoding="utf-8") as f:
            txt = f.read()
        docs.append(Document(page_content=txt, metadata={"tenant": TENANT_ID, "source": os.path.basename(fp)}))

    if not docs:
        # Build an empty index to avoid boot failure
        return FAISS.from_texts([""], embeddings, metadatas=[{"tenant": TENANT_ID, "source": "empty"}])

    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=120)
    chunks = splitter.split_documents(docs)
    vs = FAISS.from_documents(chunks, embeddings)
    vs.save_local(faiss_path)
    return vs

vectorstore = load_or_build_index()
retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

# ---- LLM (OpenAI-compatible via vLLM) ----
llm = ChatOpenAI(
    model="nvidia/NVIDIA-Nemotron-Nano-9B-v2",  # name is forwarded to vLLM server
    base_url=VLLM_BASE_URL,
    api_key=OPENAI_API_KEY,
    temperature=0.2,
    max_tokens=512,
)

SYSTEM_PROMPT = (
    "You are a precise assistant. Use ONLY the provided context. "
    "If the answer is not contained in the context, say you don't know."
)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", SYSTEM_PROMPT),
        ("human", "Question: {question}\n\nContext:\n{context}\n\nAnswer concisely:")
    ]
)

def format_docs(docs: List[Document]) -> str:
    out = []
    for d in docs:
        src = d.metadata.get("source", "unknown")
        out.append(f"[{src}] {d.page_content}")
    return "\n\n".join(out)

# LCEL pipeline
chain = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | prompt
    | llm
)

# ---- FastAPI ----
app = FastAPI(title=f"RAG Service – {TENANT_ID}", version="1.0.0")

class Query(BaseModel):
    question: str

@app.get("/health")
def health():
    return {"status": "ok", "tenant": TENANT_ID}

@app.post("/query")
def query(payload: Query = Body(...)):
    # Per-tenant retriever ensures isolation; no cross-tenant access is possible.
    resp = chain.invoke(payload.question)
    return {"answer": resp.content, "tenant": TENANT_ID}
